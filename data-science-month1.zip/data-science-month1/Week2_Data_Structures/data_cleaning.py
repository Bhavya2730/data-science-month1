# Data Cleaning Script
# Remove duplicates and filter data

def remove_duplicates(data):
    unique_data = []
    
    for item in data:
        if item not in unique_data:
            unique_data.append(item)
    
    return unique_data


def filter_even_numbers(data):
    filtered_data = []
    
    for num in data:
        if num % 2 == 0:
            filtered_data.append(num)
    
    return filtered_data


# Sample dataset
numbers = [10, 20, 20, 30, 40, 40, 50, 60]

print("Original Data:", numbers)

# Remove duplicates
clean_data = remove_duplicates(numbers)
print("After Removing Duplicates:", clean_data)

# Filter even numbers
even_numbers = filter_even_numbers(clean_data)
print("Filtered Even Numbers:", even_numbers)