# Week 4 – Data Visualization with Matplotlib and Seaborn

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Sample dataset
data = {
    "Age": [20, 21, 22, 23, 24, 25, 26],
    "Study_Hours": [2, 3, 4, 5, 3, 4, 6],
    "Score": [60, 65, 70, 75, 72, 78, 85]
}

df = pd.DataFrame(data)

# ---------- Histogram ----------
plt.figure(figsize=(6,4))
plt.hist(df["Score"], bins=5, color="skyblue")
plt.title("Distribution of Scores")
plt.xlabel("Score")
plt.ylabel("Frequency")
plt.show()

# ---------- Scatter Plot ----------
plt.figure(figsize=(6,4))
plt.scatter(df["Study_Hours"], df["Score"], color="green")
plt.title("Study Hours vs Score")
plt.xlabel("Study Hours")
plt.ylabel("Score")
plt.show()

# ---------- Seaborn Heatmap ----------
plt.figure(figsize=(6,4))
correlation = df.corr()
sns.heatmap(correlation, annot=True, cmap="coolwarm")
plt.title("Feature Correlation Heatmap")
plt.show()

# ---------- Seaborn Pairplot ----------
sns.pairplot(df)
plt.show()